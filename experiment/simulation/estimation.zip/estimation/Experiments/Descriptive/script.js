//javascript file for descriptive statistics experiments



function createSampleInputs() {
    const numSamples = parseInt(document.getElementById('numSamples').value);
    const sampleInputContainer = document.getElementById('sampleInputContainer');
    const sampleSelectionContainer = document.getElementById('sampleSelectionContainer');

    sampleInputContainer.innerHTML = '';
    sampleSelectionContainer.innerHTML = '';

    for (let i = 1; i <= numSamples; i++) {
        const label = document.createElement('label');
        label.htmlFor = `Sample_${i}`;
        label.textContent = `Sample ${i}: `;

        const input = document.createElement('input');
        input.type = 'text'; // Change the input type to 'text'
        input.id = `Sample_${i}`;
        input.name = `Sample_${i}`;
        input.placeholder = `Enter values for Sample ${i} with space in between`;
        input.classList.add('sample-input');

        sampleInputContainer.appendChild(label);
        sampleInputContainer.appendChild(input);
        sampleInputContainer.appendChild(document.createElement('br'));

        // Create checkbox for sample selection
        const checkboxLabel = document.createElement('label');
        checkboxLabel.htmlFor = `Checkbox_${i}`;
        checkboxLabel.textContent = `Sample ${i} `;

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.id = `Checkbox_${i}`;
        checkbox.name = `Checkbox_${i}`;
        checkbox.value = `Sample_${i}`;

        sampleSelectionContainer.appendChild(checkboxLabel);
        sampleSelectionContainer.appendChild(checkbox);
        sampleSelectionContainer.appendChild(document.createElement('br'));
    }

    document.getElementById("regressionButton").style.display = numSamples >= 2 ? "block" : "none";

    // Function to get the data from the input fields
}

function getData() {
    const numSamples = parseInt(document.getElementById('numSamples').value);
    const data2DArray = [];

    for (let i = 1; i <= numSamples; i++) {
        const inputId = `Sample_${i}`;
        let dataString = document.getElementById(inputId).value.trim();
        dataString = dataString.replace(/\s+/g, " ");

        const dataArray = dataString.split(/\s+/).map(Number);
        data2DArray.push(dataArray);
    }

    console.log(data2DArray);
    return data2DArray;
}

// function getData() {
//     // extacting data points into an array from the string of Sample_1

//     // extacting data points into an array from the string of Sample_1
//     let dataString = document.getElementById("Sample_1").value;
//     let freqString = document.getElementById("Sample_2").value;

//     // removing extra space char at the bigginnig and end of inputed data
//     dataString = dataString.trim();
//     freqString = freqString.trim();

//     // removing extra space in-between the data values in the data strings
//     dataString = dataString.replace(/\s+/g, " ");
//     freqString = freqString.replace(/\s+/g, " ");

//     // defining a test to check whether the data in class data or not
//     let classtest = /\d+[-]\d+/;

//     // testing data string for classinput
//     //if is is class data data we will return classdatafreq array if not we will return normal freqdataAray
//     if (classtest.test(dataString)) {
//         let dataArrayString = "";
//         dataArrayString = dataString.split(" ");
//         console.log(dataArrayString);
//     }

//     // making an num array from the string of point data
//     let dataArray = dataString.split(" ");
//     for (let x = 0; x < dataArray.length; x++) {
//         dataArray[x] = +dataArray[x];
//     }

//     // making an num array from the string of freq data
//     let freqArray = freqString.split(" ");
//     for (let x = 0; x < freqArray.length; x++) {
//         freqArray[x] = +freqArray[x];
//     }

//     let freqDataArray = [];

//     if (freqArray.length !== dataArray.length) {
//         alert("number of data and freqencies don't match");
//     } else {
//         freqDataArray.push(dataArray);
//         freqDataArray.push(freqArray);
//     }
//     console.log(freqDataArray);
//     return freqDataArray;
// }


// // function getFlatData() {
// //     // extacting data points into an array from the string of Sample_1

// //     // extacting data points into an array from the string of Sample_1
// //     let dataString = document.getElementById("Sample_1").value;
// //     let freqString = document.getElementById("Sample_2").value;

// //     // removing extra space char at the bigginnig and end of inputed data
// //     dataString = dataString.trim();
// //     freqString = freqString.trim();

// //     // removing extra space in-between the data values in the data strings
// //     dataString = dataString.replace(/\s+/g, " ");
// //     freqString = freqString.replace(/\s+/g, " ");

// //     // defining a test to check whether the data in class data or not
// //     let classtest = /\d+[-]\d+/;

// //     // testing data string for classinput
// //     //if is is class data data we will return classdatafreq array if not we will return normal freqdataAray
// //     if (classtest.test(dataString)) {
// //         let dataArrayString = "";
// //         dataArrayString = dataString.split(" ");
// //         console.log(dataArrayString);
// //     }

// //     // making an num array from the string of point data
// //     let dataArray = dataString.split(" ");
// //     for (let x = 0; x < dataArray.length; x++) {
// //         dataArray[x] = +dataArray[x];
// //     }

// //     // making an num array from the string of freq data
// //     let freqArray = freqString.split(" ");
// //     for (let x = 0; x < freqArray.length; x++) {
// //         freqArray[x] = +freqArray[x];
// //     }

// //     let freqDataArray = [];

// //     if (freqArray.length !== dataArray.length) {
// //         alert("number of data and freqencies don't match");
// //     } else {

// //         for (let k = 0; k < dataArray.length; k++) {
// //             let tempArray = []
// //             for (let i = freqArray[k]; i > 0; i--) {
// //                 tempArray.push(dataArray[k]);
// //             }
// //             // tempArray.push(freqArray[k]);
// //             freqDataArray.push(tempArray);
// //         }
// //     }

// //     freqDataArray = freqDataArray.flat();
// //     // console.log(freqDataArray)
// //     return freqDataArray;
// // }

//---------------------------------------------------------------------
// Start of all Charting Functions
//---------------------------------------------------------------------

// Start of Line Chart Plot funtion


google.charts.load("current", { packages: ["corechart"] });

function makeLineChart() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');

    // Validate the number of checkboxes selected
    if (checkboxes.length !== 2) {
        alert("Please select exactly two samples for plotting.");
        return;
    }

    // Get the sample IDs from the checkboxes
    const sampleIds = Array.from(checkboxes).map(checkbox => checkbox.value);

    // Getting data for the selected samples
    const mydata = sampleIds.map(sampleId => {
        const input = document.getElementById(sampleId);
        const values = input.value.trim().split(/\s+/).map(Number);
        return {
            label: sampleId,
            values: values
        };
    });

    let data = new google.visualization.DataTable();
    mydata.forEach(sample => {
        data.addColumn("number", sample.label);
    });

    let rows = [];
    const numRows = Math.min(...mydata.map(sample => sample.values.length));

    for (let i = 0; i < numRows; i++) {
        let tempArray = mydata.map(sample => sample.values[i]);
        rows.push(tempArray);
    }

    data.addRows(rows);

    // Set options
    var options = {
        title: "Line Chart",
        hAxis: { title: mydata[0].label },
        vAxis: { title: mydata[1].label },
        legend: "both",
        series: mydata.map((sample, index) => ({ color: index === 0 ? "#e2431e" : "#4374e0", labelInLegend: sample.label }))
    };

    // Draw Chart
    var chart = new google.visualization.LineChart(
        document.getElementById("myChart")
    );
    chart.draw(data, options);
}
// End of Line Chart Plot funtion


//---------------------------------------------------------------------
// Start of scatter chart plot function
function makeScatterChart() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');

    // Validate the number of checkboxes selected
    if (checkboxes.length !== 2) {
        alert("Please select exactly two samples for plotting.");
        return;
    }

    // Get the sample IDs from the checkboxes
    const sampleIds = Array.from(checkboxes).map(checkbox => checkbox.value);

    // Getting data for the selected samples
    const mydata = sampleIds.map(sampleId => {
        const input = document.getElementById(sampleId);
        const values = input.value.trim().split(/\s+/).map(Number);
        return {
            label: sampleId,
            values: values
        };
    });

    let data = new google.visualization.DataTable();
    data.addColumn("number", mydata[0].label);
    data.addColumn("number", mydata[1].label);

    let rows = [];
    const numRows = Math.min(...mydata.map(sample => sample.values.length));

    for (let i = 0; i < numRows; i++) {
        let tempArray = mydata.map(sample => sample.values[i]);
        rows.push(tempArray);
    }

    data.addRows(rows);

    // Set options
    var options = {
        title: "Scatter Plot",
        hAxis: { title: mydata[0].label },
        vAxis: { title: mydata[1].label },
        legend: "none",
        pointSize: 5,
        series: {
            0: { color: "#e2431e" }
        }
    };

    // Draw Chart
    var chart = new google.visualization.ScatterChart(
        document.getElementById("myChart")
    );
    chart.draw(data, options);
}



// End of Scatter Chart graph plot function
//--------------------------------------------------------------------










// Start of Area chart plot function
function makeAreaChart() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');

    // Validate the number of checkboxes selected
    if (checkboxes.length !== 2) {
        alert("Please select exactly two samples for plotting.");
        return;
    }

    // Get the sample IDs from the checkboxes
    const sampleIds = Array.from(checkboxes).map(checkbox => checkbox.value);

    // Getting data for the selected samples
    const mydata = sampleIds.map(sampleId => {
        const input = document.getElementById(sampleId);
        const values = input.value.trim().split(/\s+/).map(Number);
        return {
            label: sampleId,
            values: values
        };
    });

    let data = new google.visualization.DataTable();
    data.addColumn("number", mydata[0].label);
    data.addColumn("number", mydata[1].label);

    let rows = [];
    const numRows = Math.min(...mydata.map(sample => sample.values.length));

    for (let i = 0; i < numRows; i++) {
        let tempArray = mydata.map(sample => sample.values[i]);
        rows.push(tempArray);
    }

    data.addRows(rows);

    // Set options
    var options = {
        title: "Area Graph",
        hAxis: { title: mydata[0].label },
        vAxis: { title: mydata[1].label },
        legend: "none",
        series: {
            0: { color: "#e2431e" }
        }
    };

    // Draw Chart
    var chart = new google.visualization.AreaChart(
        document.getElementById("myChart")
    );
    chart.draw(data, options);
}


// End of Scatter Chart graph plot function
//--------------------------------------------------------------------






//--------------------------------------------------------------------

// Start of Table plot code
google.charts.load("current", { packages: ["table"] });
// Start of Table plot function
function makeTableChart() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');

    // Validate the number of checkboxes selected
    if (checkboxes.length !== 2) {
        alert("Please select exactly two samples for plotting.");
        return;
    }

    // Get the sample IDs from the checkboxes
    const sampleIds = Array.from(checkboxes).map(checkbox => checkbox.value);

    // Getting data for the selected samples
    const mydata = sampleIds.map(sampleId => {
        const input = document.getElementById(sampleId);
        const values = input.value.trim().split(/\s+/).map(Number);
        return values;
    });

    let data = new google.visualization.DataTable();
    data.addColumn("number", sampleIds[0]);
    data.addColumn("number", sampleIds[1]);

    let rows = [];
    const numRows = Math.min(...mydata.map(sample => sample.length));

    for (let i = 0; i < numRows; i++) {
        let tempArray = mydata.map(sample => sample[i]);
        rows.push(tempArray);
    }

    data.addRows(rows);

    // Set Options
    let options = {
        title: "Data Table",
        showRowNumber: true,
        alternatingRowStyle: true,
        explorer: { axis: "horizontal", keepInBounds: true },
    };

    // Draw Chart
    var chart = new google.visualization.Table(
        document.getElementById("myChart")
    );
    chart.draw(data, options);
}


// End of Table Chart graph plot function
//--------------------------------------------------------------------

//---------------------------------------------------------------------
// End of all Charting Functions
//---------------------------------------------------------------------


// Function to calculate the confidence interval for a given dataset and confidence level
//part1/////////////////
///////////////////////////
////////////////////////////
///////////////////////////////
// Function to calculate the confidence interval for the mean

function NormSInv(p) {
    var a1 = -39.6968302866538,
        a2 = 220.946098424521,
        a3 = -275.928510446969;
    var a4 = 138.357751867269,
        a5 = -30.6647980661472,
        a6 = 2.50662827745924;
    var b1 = -54.4760987982241,
        b2 = 161.585836858041,
        b3 = -155.698979859887;
    var b4 = 66.8013118877197,
        b5 = -13.2806815528857,
        c1 = -7.78489400243029E-03;
    var c2 = -0.322396458041136,
        c3 = -2.40075827716184,
        c4 = -2.54973253934373;
    var c5 = 4.37466414146497,
        c6 = 2.93816398269878,
        d1 = 7.78469570904146E-03;
    var d2 = 0.32246712907004,
        d3 = 2.445134137143,
        d4 = 3.75440866190742;
    var p_low = 0.02425,
        p_high = 1 - p_low;
    var q, r;
    var retVal;

    if ((p < 0) || (p > 1)) {
        alert("NormSInv: Argument out of range.");
        retVal = 0;
    } else if (p < p_low) {
        q = Math.sqrt(-2 * Math.log(p));
        retVal = (((((c1 * q + c2) * q + c3) * q + c4) * q + c5) * q + c6) / ((((d1 * q + d2) * q + d3) * q + d4) * q + 1);
    } else if (p <= p_high) {
        q = p - 0.5;
        r = q * q;
        retVal = (((((a1 * r + a2) * r + a3) * r + a4) * r + a5) * r + a6) * q / (((((b1 * r + b2) * r + b3) * r + b4) * r + b5) * r + 1);
    } else {
        q = Math.sqrt(-2 * Math.log(1 - p));
        retVal = -(((((c1 * q + c2) * q + c3) * q + c4) * q + c5) * q + c6) / ((((d1 * q + d2) * q + d3) * q + d4) * q + 1);
    }

    return retVal;
}


function calculateConfidenceIntervalForMean(data, confidenceLevel) {
    const n = data.length;
    const degreesOfFreedom = n - 1;
    const sampleMean = data.reduce((sum, item) => sum + item, 0) / n;
    const sampleStandardDeviation = calculateStandardDeviation(data);
    const zValue = jStat.studentt.inv((1 - confidenceLevel) / 2, degreesOfFreedom);

    const marginOfError = zValue * (sampleStandardDeviation / Math.sqrt(n));
    const lowerBound = sampleMean - marginOfError;
    const upperBound = sampleMean + marginOfError;

    return [upperBound, lowerBound];
}

// Function to calculate the standard deviation
function calculateStandardDeviation(data) {
    const n = data.length;
    const mean = data.reduce((sum, item) => sum + item, 0) / n;
    const squaredDifferences = data.map(item => Math.pow(item - mean, 2));
    const sumOfSquaredDifferences = squaredDifferences.reduce((sum, item) => sum + item, 0);
    const variance = sumOfSquaredDifferences / (n - 1);
    const standardDeviation = Math.sqrt(variance);
    return standardDeviation;
}

// Modified code to calculate confidence intervals and display the result
function calculateInterval() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');

    // Validate the number of checkboxes selected
    if (checkboxes.length !== 1) {
        alert("Please select exactly one sample.");
        return;
    }

    // Get the sample IDs from the checkboxes
    const sampleIds = Array.from(checkboxes).map(checkbox => checkbox.value);

    // Getting data for the selected samples
    const mydata = sampleIds.map(sampleId => {
        const input = document.getElementById(sampleId);
        const values = input.value.trim().split(/\s+/).map(Number);
        return {
            label: sampleId,
            values: values
        };
    });

    const confidenceLevelInput = document.getElementById('confidenceLevel');
    const confidenceLevel = parseFloat(confidenceLevelInput.value) / 100; // Convert percentage to decimal

    // Check if the input is a valid number between 0 and 100
    if (isNaN(confidenceLevel) || confidenceLevel < 0 || confidenceLevel > 100) {
        alert("Please enter a valid confidence level between 0 and 100.");
        return;
    }

    // Calculate confidence interval for the mean of each sample
    const confidenceIntervals = mydata.map(sample => {
        const data = sample.values;
        const [lowerBound, upperBound] = calculateConfidenceIntervalForMean(data, confidenceLevel);
        return {
            label: sample.label,
            confidenceInterval: [lowerBound, upperBound]
        };
    });

    // Display confidence intervals in the HTML element
    const resultArea = document.getElementById('data-result-area');
    resultArea.innerHTML = ''; // Clear previous results
    confidenceIntervals.forEach(interval => {
        const label = interval.label;
        const lowerBound = interval.confidenceInterval[0];
        const upperBound = interval.confidenceInterval[1];

        const intervalText = `${(confidenceLevel*100).toFixed(2)}% Confidence Interval for the mean of ${label}: [${lowerBound.toFixed(2)}, ${upperBound.toFixed(2)}]`;
        const intervalElement = document.createElement('p');
        intervalElement.textContent = intervalText;
        resultArea.appendChild(intervalElement);
    });
}


// Function to calculate the confidence interval for the variance of a given dataset and confidence level
function calculateConfidenceIntervalForVariance(data, confidenceLevel) {
    const n = data.length;
    const degreesOfFreedom = n - 1;
    const sampleVariance = calculateVariance(data);
    const alpha = 1 - confidenceLevel;
    const chiSquaredLower = jStat.chisquare.inv(1 - alpha / 2, degreesOfFreedom);
    const chiSquaredUpper = jStat.chisquare.inv((alpha / 2), degreesOfFreedom);
    console.log(`Chi Squared Lower is  ${chiSquaredLower}`);
    console.log(`Chi Squared Upper is  ${chiSquaredUpper}`);
    const lowerBound = (degreesOfFreedom * sampleVariance) / chiSquaredLower;
    const upperBound = (degreesOfFreedom * sampleVariance) / chiSquaredUpper;

    return [lowerBound, upperBound];
}

// Function to calculate the sample variance
function calculateVariance(data) {
    const mean = data.reduce((sum, item) => sum + item, 0) / data.length;
    const squaredDifferences = data.map(item => Math.pow(item - mean, 2));
    const variance = squaredDifferences.reduce((sum, item) => sum + item, 0) / (data.length - 1);
    console.log(`VAriace  is  ${variance}`);
    return variance;
}


// Modified code to calculate confidence intervals for variance and display the result
function calculateInterval2() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');

    // Validate the number of checkboxes selected
    if (checkboxes.length !== 1) {
        alert("Please select exactly one sample.");
        return;
    }

    // Get the sample IDs from the checkboxes
    const sampleIds = Array.from(checkboxes).map(checkbox => checkbox.value);

    // Getting data for the selected samples
    const mydata = sampleIds.map(sampleId => {
        const input = document.getElementById(sampleId);
        const values = input.value.trim().split(/\s+/).map(Number);
        return {
            label: sampleId,
            values: values
        };
    });

    const confidenceLevelInput = document.getElementById('confidenceLevel');
    const confidenceLevel = parseFloat(confidenceLevelInput.value) / 100; // Convert percentage to decimal

    // Check if the input is a valid number between 1 and 100
    if (isNaN(confidenceLevel) || confidenceLevel < 0 || confidenceLevel > 1) {
        alert("Please enter a valid confidence level between 1 and 100.");
        return;
    }

    // Calculate confidence interval for the variance of each sample
    const confidenceIntervals = mydata.map(sample => {
        const data = sample.values;
        const [lowerBound, upperBound] = calculateConfidenceIntervalForVariance(data, confidenceLevel);
        return {
            label: sample.label,
            confidenceInterval: [lowerBound, upperBound]
        };
    });

    // Display confidence intervals in the HTML element
    const resultArea = document.getElementById('data-result-area');
    resultArea.innerHTML = ''; // Clear previous results
    confidenceIntervals.forEach(interval => {
        const label = interval.label;
        const lowerBound = interval.confidenceInterval[0];
        const upperBound = interval.confidenceInterval[1];
        // const sampleVariance = interval.confidenceInterval[2];
        // console.log(`sample variance : ${sampleVariance}`);
        const intervalText = `${(confidenceLevel*100).toFixed(2)}% confidence interval for Variance of ${label}: [${lowerBound.toFixed(2)}, ${upperBound.toFixed(2)}] }}`;
        const intervalElement = document.createElement('p');
        intervalElement.textContent = intervalText;
        resultArea.appendChild(intervalElement);
    });
}


///part 3

// Function to calculate the confidence interval for the ratio of variances of two samples
function calculateConfidenceIntervalForRatioOfVariances(data1, data2, confidenceLevel) {
    const n1 = data1.length;
    const n2 = data2.length;
    const degreesOfFreedom1 = n1 - 1;
    const degreesOfFreedom2 = n2 - 1;
    const variance1 = calculateVariance(data1);
    const variance2 = calculateVariance(data2);
    const alpha = 1 - confidenceLevel;
    const fLower = jStat.centralF.inv(alpha / 2, degreesOfFreedom1, degreesOfFreedom2);
    const fUpper = jStat.centralF.inv(alpha / 2, degreesOfFreedom2, degreesOfFreedom1);

    const lowerBound = (variance1 / variance2) * (1 / fLower);
    const upperBound = (variance1 / variance2) * (fUpper);

    return [upperBound, lowerBound];
}


function calculateInterval3() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');

    // Validate the number of checkboxes selected
    if (checkboxes.length !== 2) {
        alert("Please select exactly two samples.");
        return;
    }

    // Get the sample IDs from the checkboxes
    const sampleIds = Array.from(checkboxes).map(checkbox => checkbox.value);

    // Getting data for the selected samples
    const mydata = sampleIds.map(sampleId => {
        const input = document.getElementById(sampleId);
        const values = input.value.trim().split(/\s+/).map(Number);
        return {
            label: sampleId,
            values: values
        };
    });

    const confidenceLevelInput = document.getElementById('confidenceLevel');
    const confidenceLevel = parseFloat(confidenceLevelInput.value) / 100; // Convert percentage to decimal

    // Check if the input is a valid number between 1 and 100
    if (isNaN(confidenceLevel) || confidenceLevel < 0 || confidenceLevel > 1) {
        alert("Please enter a valid confidence level between 1 and 100.");
        return;
    }

    // Calculate confidence interval for the ratio of variances of the two samples
    const sample1 = mydata[0].values;
    const sample2 = mydata[1].values;
    const [lowerBound, upperBound] = calculateConfidenceIntervalForRatioOfVariances(sample1, sample2, confidenceLevel);

    // Display confidence interval in the HTML element
    const resultArea = document.getElementById('data-result-area');
    resultArea.innerHTML = ''; // Clear previous results

    const intervalText = `${(confidenceLevel * 100).toFixed(2)}% confidence interval for Ratio of Variances: [${lowerBound.toFixed(2)}, ${upperBound.toFixed(2)}]`;
    const intervalElement = document.createElement('p');
    intervalElement.textContent = intervalText;
    resultArea.appendChild(intervalElement);
}



function estimateNormalParameters(data) {
    var n = data.length;

    // Calculate the sample mean
    var sum = 0;
    for (var i = 0; i < n; i++) {
        sum += data[i];
    }
    var sampleMean = sum / n;

    // Calculate the sample variance
    var squaredDifferencesSum = 0;
    for (var i = 0; i < n; i++) {
        var difference = data[i] - sampleMean;
        squaredDifferencesSum += difference * difference;
    }
    var sampleVariance = squaredDifferencesSum / n;

    // Return the estimated mean and variance
    return {
        mean: sampleMean,
        variance: sampleVariance
    };
}

function normal() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');

    // Validate the number of checkboxes selected
    if (checkboxes.length !== 1) {
        alert("Please select exactly one sample.");
        return;
    }

    // Get the sample IDs from the checkboxes
    const sampleIds = Array.from(checkboxes).map(checkbox => checkbox.value);

    // Getting data for the selected samples
    const mydata = sampleIds.map(sampleId => {
        const input = document.getElementById(sampleId);
        const values = input.value.trim().split(/\s+/).map(Number);
        return {
            label: sampleId,
            values: values
        };
    });

    // Estimate mean and variance
    const estimatedParameters = estimateNormalParameters(mydata[0].values);
    const estimatedMean = estimatedParameters.mean;
    const estimatedVariance = estimatedParameters.variance;

    // Display estimated mean and variance
    const resultArea = document.getElementById('data-result-area');
    resultArea.innerHTML = ''; // Clear previous results

    const meanElement = document.createElement('p');
    meanElement.textContent = `MLE Mean: ${estimatedMean.toFixed(2)}`;
    resultArea.appendChild(meanElement);

    const varianceElement = document.createElement('p');
    varianceElement.textContent = `MLE Variance: ${estimatedVariance.toFixed(2)}`;
    resultArea.appendChild(varianceElement);
}

function estimateExponentialParameter(data) {
    var n = data.length;

    // Calculate the reciprocal of the sample mean
    var sum = 0;
    for (var i = 0; i < n; i++) {
        sum += data[i];
    }
    var reciprocalMean = n / sum;

    // Calculate the estimated parameter lambda


    return reciprocalMean;
}

function exp() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');

    // Validate the number of checkboxes selected
    if (checkboxes.length !== 1) {
        alert("Please select exactly one sample.");
        return;
    }

    // Get the sample IDs from the checkboxes
    const sampleIds = Array.from(checkboxes).map(checkbox => checkbox.value);

    // Getting data for the selected samples
    const mydata = sampleIds.map(sampleId => {
        const input = document.getElementById(sampleId);
        const values = input.value.trim().split(/\s+/).map(Number);
        return {
            label: sampleId,
            values: values
        };
    });

    // Estimate mean and variance
    const estimatedParameters = estimateExponentialParameter(mydata[0].values);

    // Display estimated mean and variance
    const resultArea = document.getElementById('data-result-area');
    resultArea.innerHTML = ''; // Clear previous results

    const meanElement = document.createElement('p');
    meanElement.textContent = `MLE λ : ${estimatedParameters.toFixed(2)}`;
    resultArea.appendChild(meanElement);

}

function estimatePoissonParameter(data) {
    var n = data.length;

    // Calculate the sample mean
    var sum = 0;
    for (var i = 0; i < n; i++) {
        sum += data[i];
    }
    var sampleMean = sum / n;

    // Return the estimated lambda
    return sampleMean;
}

function poisson() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');

    // Validate the number of checkboxes selected
    if (checkboxes.length !== 1) {
        alert("Please select exactly one sample.");
        return;
    }

    // Get the sample IDs from the checkboxes
    const sampleIds = Array.from(checkboxes).map(checkbox => checkbox.value);

    // Getting data for the selected samples
    const mydata = sampleIds.map(sampleId => {
        const input = document.getElementById(sampleId);
        const values = input.value.trim().split(/\s+/).map(Number);
        return {
            label: sampleId,
            values: values
        };
    });

    // Estimate lambda
    const estimatedLambda = estimatePoissonParameter(mydata[0].values);

    // Display estimated lambda
    const resultArea = document.getElementById('data-result-area');
    resultArea.innerHTML = ''; // Clear previous results

    const lambdaElement = document.createElement('p');
    lambdaElement.textContent = `MLE λ: ${estimatedLambda.toFixed(2)}`;
    resultArea.appendChild(lambdaElement);
}