

- current tasks 
    -  consolidate project website.
    -  remove non-working elements form ui
    -  preserve state of data in datafield
    -  highlight statistic in the graph
    -   moment ( graphs and computation)

connect all graphs (Bar graph, Pie graph, Area graph, scatter plot etc)to the real data and remove from default data.
Run code for Mean, medain and modeRun code for  

1. Write code for connecting the mean and median directly without reload.
2. Write code for mean, median ,mode with plotting. 
3. Write code for calculate button.
4. Issue an alert message when calculataion is attempted with negative frequency data 
5.  
